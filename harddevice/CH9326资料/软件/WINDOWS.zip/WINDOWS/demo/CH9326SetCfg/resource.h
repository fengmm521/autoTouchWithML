//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CH9326SetCfg.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CH9326SETCFG_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_COMBO_SELECT_DEV            1000
#define IDC_EDIT_STATUS                 1001
#define IDC_EDIT_CHABA                  1002
#define IDC_COMBO_RATE                  1003
#define IDC_COMBO_STOP                  1004
#define IDC_COMBO_CHECK                 1005
#define IDC_COMBO_DATA                  1006
#define IDC_CHECK_VID                   1007
#define IDC_EDIT_VID                    1008
#define IDC_CHECK_PID                   1009
#define IDC_EDIT_PID                    1010
#define IDC_CHECK_MS                    1013
#define IDC_EDIT_MSTRING                1014
#define IDC_CHECK_PS                    1015
#define IDC_EDIT_PSTRING                1016
#define IDC_CHECK_SS                    1017
#define IDC_EDIT_SSTRING                1018
#define IDC_BUTTON_OPEN                 1019
#define IDC_BUTTON_SETREPORT            1020
#define IDC_BUTTON_SET_CFG              1021
#define IDC_BUTTON_GET_CFG              1022
#define IDC_RADIO_IO5_INPUT             1023
#define IDC_RADIO_IO5_OUTPUT            1024
#define IDC_RADIO_IO5_HIGH              1025
#define IDC_RADIO_IO5_LOW               1026
#define IDC_RADIO_IO6_INPUT             1027
#define IDC_RADIO_IO6_OUTPUT            1028
#define IDC_RADIO_IO6_HIGH              1029
#define IDC_RADIO_IO6_LOW               1030
#define IDC_RADIO_IO7_INPUT             1031
#define IDC_RADIO_IO7_OUTPUT            1032
#define IDC_RADIO_IO7_HIGH              1033
#define IDC_RADIO_IO7_LOW               1034
#define IDC_RADIO_IO8_INPUT             1035
#define IDC_RADIO_IO8_OUTPUT            1036
#define IDC_RADIO_IO8_HIGH              1037
#define IDC_RADIO_IO8_LOW               1038
#define IDC_RADIO_IO9_INPUT             1039
#define IDC_RADIO_IO9_OUTPUT            1040
#define IDC_RADIO_IO9_HIGH              1041
#define IDC_RADIO_IO9_LOW               1042
#define IDC_RADIO_IO10_INPUT            1043
#define IDC_RADIO_IO10_OUTPUT           1044
#define IDC_RADIO_IO10_HIGH             1045
#define IDC_RADIO_IO10_LOW              1046
#define IDC_BUTTON_SETIO                1047
#define IDC_BUTTON_SET_OUTPUT           1048
#define IDC_BUTTON_GETIO                1049
#define IDC_BUTTON_SET_DEF              1050
#define IDC_BUTTON_SET_DEFUALT          1050
#define IDC_RADIO_IO11_INPUT            1071
#define IDC_RADIO_IO11_OUTPUT           1072
#define IDC_RADIO_IO11_HIGH             1073
#define IDC_RADIO_IO11_LOW              1074
#define IDC_RADIO_IO12_INPUT            1075
#define IDC_RADIO_IO12_OUTPUT           1076
#define IDC_RADIO_IO12_HIGH             1077
#define IDC_RADIO_IO12_LOW              1078
#define IDC_RADIO_IO13_INPUT            1079
#define IDC_RADIO_IO13_OUTPUT           1080
#define IDC_RADIO_IO13_HIGH             1081
#define IDC_RADIO_IO13_LOW              1082
#define IDC_RADIO_IO14_INPUT            1083
#define IDC_RADIO_IO14_OUTPUT           1084
#define IDC_RADIO_IO14_HIGH             1085
#define IDC_RADIO_IO14_LOW              1086
#define IDC_RADIO_IO15_INPUT            1087
#define IDC_RADIO_IO15_OUTPUT           1088
#define IDC_RADIO_IO15_HIGH             1089
#define IDC_RADIO_IO15_LOW              1090
#define IDC_RADIO_IO16_INPUT            1091
#define IDC_RADIO_IO16_OUTPUT           1092
#define IDC_RADIO_IO16_HIGH             1093
#define IDC_RADIO_IO16_LOW              1094

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
