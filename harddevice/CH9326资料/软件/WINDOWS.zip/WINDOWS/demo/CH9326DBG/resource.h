//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CH9326DBG.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CH9326DBG_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_COMBO_SELECT_DEV            1000
#define IDC_EDIT_STATUS                 1001
#define IDC_EDIT_CHABA                  1002
#define IDC_COMBO_RATE                  1003
#define IDC_COMBO_CHECK                 1004
#define IDC_COMBO_STOP                  1005
#define IDC_COMBO_DATA                  1006
#define IDC_EDIT_SEND                   1007
#define IDC_EDIT_RECVED                 1008
#define IDC_EDIT_RECV                   1009
#define IDC_BUTTON_OPEN                 1010
#define IDC_BUTTON_SETREPORT            1011
#define IDC_BUTTON_SEND                 1012
#define IDC_BUTTON_RECV                 1013
#define IDC_BUTTON_STOP                 1014
#define IDC_BUTTON_CLEAR                1015
#define IDC_RADIO_IO1_INPUT             1016
#define IDC_RADIO_IO1_OUTPUT            1017
#define IDC_RADIO_IO1_HIGH              1018
#define IDC_RADIO_IO1_LOW               1019
#define IDC_RADIO_IO2_INPUT             1020
#define IDC_RADIO_IO2_OUTPUT            1021
#define IDC_RADIO_IO2_HIGH              1022
#define IDC_RADIO_IO2_LOW               1023
#define IDC_BUTTON_SETIO                1024
#define IDC_BUTTON_GETIO                1025
#define IDC_RADIO_IO3_INPUT             1026
#define IDC_RADIO_IO3_OUTPUT            1027
#define IDC_RADIO_IO3_HIGH              1028
#define IDC_RADIO_IO3_LOW               1029
#define IDC_RADIO_IO4_INPUT             1030
#define IDC_RADIO_IO4_OUTPUT            1031
#define IDC_RADIO_IO4_HIGH              1032
#define IDC_RADIO_IO4_LOW               1033
#define IDC_BUTTON_SET_OUTPUT           1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
