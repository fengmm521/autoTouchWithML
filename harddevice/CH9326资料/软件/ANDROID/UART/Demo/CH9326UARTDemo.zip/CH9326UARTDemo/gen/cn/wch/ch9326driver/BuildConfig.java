/** Automatically generated file. DO NOT MODIFY */
package cn.wch.ch9326driver;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}