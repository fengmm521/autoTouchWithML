package cn.wch.ch9326driver;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity {

	private final String ACTION_USB_PERMISSION = "cn.wch.CH9326UARTDemoDriver.USB_PERMISSION";
	private EditText readText;
	private EditText writeText;
	private Spinner baudSpinner;
	private Spinner stopSpinner;
	private Spinner dataSpinner;
	private Spinner paritySpinner;
	private Button openButton, writeButton, configButton, clearButton;

	private int baud;
	private int stop_bit;
	private int data_bit;
	private int parity;
	private boolean isOpen;
	private static Handler handler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		MyApp.driver = new CH9326UARTDriver(
				(UsbManager) getSystemService(Context.USB_SERVICE), this,
				ACTION_USB_PERMISSION);
		initUI();
		if (!MyApp.driver.UsbFeatureSupported())// �ж�ϵͳ�Ƿ�֧��USB HOST
		{
			Dialog dialog = new AlertDialog.Builder(MainActivity.this)
					.setTitle("��ʾ")
					.setMessage("�����ֻ���֧��USB HOST������������ֻ����ԣ�")
					.setPositiveButton("ȷ��",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface arg0,
										int arg1) {
									System.exit(0);
								}
							}).create();
			dialog.setCanceledOnTouchOutside(false);
			dialog.show();
		}
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);// ���ֳ�������Ļ��״̬
		isOpen = false;
		// ��ǰ��Ĭ��ֵ
		baud = 6;
		stop_bit = 1;
		data_bit = 4;
		parity = 4;

		openButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (!isOpen) {
					if (MyApp.driver.ResumeUsbList()) {//ִ��ResumeUsbListö�٣��򿪲���ʼ��CH9326�豸;����ʹ��EnumerateDevice��OpenDevice
						Toast.makeText(MainActivity.this, "�豸�򿪳ɹ�!",
								Toast.LENGTH_SHORT).show();
						isOpen = true;
						openButton.setText("Close");
						new RecvThread().start();// ���������߳̽�������
						configButton.setEnabled(true);
						writeButton.setEnabled(true);
					} else {
						Toast.makeText(MainActivity.this, "�豸��ʧ��!",
								Toast.LENGTH_SHORT).show();
						return;
					}
				} else {
					isOpen = false;
					MyApp.driver.CloseDevice();// �ر��豸�ĺ���
					openButton.setText("Open");
					configButton.setEnabled(false);
					writeButton.setEnabled(false);
				}
			}
		});

		configButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (MyApp.driver.SetConfig(baud, data_bit, stop_bit, parity))//����˵������ձ���ֲ�
					Toast.makeText(MainActivity.this, "�������óɹ�!",
							Toast.LENGTH_SHORT).show();
				else
					Toast.makeText(MainActivity.this, "��������ʧ��!",
							Toast.LENGTH_SHORT).show();
			}
		});

		writeButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				String writeString = writeText.getText().toString();
				byte[] to_write = toByteArray(writeString);// ��������ڵ�ֵת��Ϊbyte����
				if (MyApp.driver.WriteData(to_write, to_write.length) < 0)//�������С��0��ʾִ��ʧ�ܣ����򷵻�ʵ��д����ֽ���
					Toast.makeText(MainActivity.this, "���ݷ���ʧ��!",
							Toast.LENGTH_SHORT).show();
			}
		});

		handler = new Handler() {
			@SuppressLint("HandlerLeak")
			@Override
			public void handleMessage(Message msg) {

				String read_string = (String) msg.obj;
				readText.append(read_string);
				super.handleMessage(msg);
			}

		};
	}

	private void initUI() {

		openButton = (Button) findViewById(R.id.open_device);
		writeButton = (Button) findViewById(R.id.WriteButton);
		configButton = (Button) findViewById(R.id.configButton);
		clearButton = (Button) findViewById(R.id.clearButton);
		configButton.setEnabled(false);
		writeButton.setEnabled(false);
		readText = (EditText) findViewById(R.id.ReadValues);
		writeText = (EditText) findViewById(R.id.WriteValues);

		baudSpinner = (Spinner) findViewById(R.id.baudRateValue);
		ArrayAdapter<CharSequence> baudAdapter = ArrayAdapter
				.createFromResource(this, R.array.baud_rate,
						R.layout.my_spinner_textview);
		baudAdapter.setDropDownViewResource(R.layout.my_spinner_textview);
		baudSpinner.setAdapter(baudAdapter);
		baudSpinner.setGravity(0x10);
		baudSpinner.setSelection(5);

		stopSpinner = (Spinner) findViewById(R.id.stopBitValue);
		ArrayAdapter<CharSequence> stopAdapter = ArrayAdapter
				.createFromResource(this, R.array.stop_bits,
						R.layout.my_spinner_textview);
		stopAdapter.setDropDownViewResource(R.layout.my_spinner_textview);
		stopSpinner.setAdapter(stopAdapter);
		stopSpinner.setGravity(0x01);

		dataSpinner = (Spinner) findViewById(R.id.dataBitValue);
		ArrayAdapter<CharSequence> dataAdapter = ArrayAdapter
				.createFromResource(this, R.array.data_bits,
						R.layout.my_spinner_textview);
		dataAdapter.setDropDownViewResource(R.layout.my_spinner_textview);
		dataSpinner.setAdapter(dataAdapter);
		dataSpinner.setGravity(0x11);
		dataSpinner.setSelection(3);

		paritySpinner = (Spinner) findViewById(R.id.parityValue);
		ArrayAdapter<CharSequence> parityAdapter = ArrayAdapter
				.createFromResource(this, R.array.parity,
						R.layout.my_spinner_textview);
		parityAdapter.setDropDownViewResource(R.layout.my_spinner_textview);
		paritySpinner.setAdapter(parityAdapter);
		paritySpinner.setGravity(0x11);

		baudSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {

				baud = arg2 + 1;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

		stopSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				stop_bit = arg2 + 1;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

		dataSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				data_bit = arg2 + 1;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

		paritySpinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				parity = arg2 + 1;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});

		clearButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				readText.setText("");
			}
		});

		paritySpinner.setSelection(3);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/**
	 * ��byte����ת��ΪString
	 * @param arg
	 *            ��Ҫת����byte[]����
	 * @param length
	 *            ��Ҫת�������鳤��
	 * @return ת�����String
	 */
	private String toHexString(byte[] arg, int length) {
		String result = new String();
		if (arg != null) {
			for (int i = 0; i < length; i++) {
				result = result
						+ (Integer.toHexString(
								arg[i] < 0 ? arg[i] + 256 : arg[i]).length() == 1 ? "0"
								+ Integer.toHexString(arg[i] < 0 ? arg[i] + 256
										: arg[i])
								: Integer.toHexString(arg[i] < 0 ? arg[i] + 256
										: arg[i])) + " ";
			}
			return result;
		}
		return "";
	}

	/**
	 * ��Stringת��Ϊbyte����
	 * @param arg
	 *            ��Ҫת����String����
	 * @return ת�����byte[]����
	 */
	private byte[] toByteArray(String arg) {
		if (arg != null) {
			/* 1.��ȥ��String�е�' '��Ȼ��Stringת��Ϊchar���� */
			char[] NewArray = new char[1000];
			char[] array = arg.toCharArray();
			int length = 0;
			for (int i = 0; i < array.length; i++) {
				if (array[i] != ' ') {
					NewArray[length] = array[i];
					length++;
				}
			}
			/* ��char�����е�ֵת��һ��ʵ�ʵ�ʮ�������� */
			int EvenLength = (length % 2 == 0) ? length : length + 1;
			if (EvenLength != 0) {
				int[] data = new int[EvenLength];
				data[EvenLength - 1] = 0;
				for (int i = 0; i < length; i++) {
					if (NewArray[i] >= '0' && NewArray[i] <= '9') {
						data[i] = NewArray[i] - '0';
					} else if (NewArray[i] >= 'a' && NewArray[i] <= 'f') {
						data[i] = NewArray[i] - 'a' + 10;
					} else if (NewArray[i] >= 'A' && NewArray[i] <= 'F') {
						data[i] = NewArray[i] - 'A' + 10;
					}
				}
				/* �� ÿ��char��ֵÿ�������һ��16�������� */
				byte[] byteArray = new byte[EvenLength / 2];
				for (int i = 0; i < EvenLength / 2; i++) {
					byteArray[i] = (byte) (data[i * 2] * 16 + data[i * 2 + 1]);
				}
				return byteArray;
			}
		}
		return new byte[] {};
	}

	// �������ݵ��߳�
	private class RecvThread extends Thread {
		byte[] recv_buff = new byte[64];
		int recv_len;
		Message msg;

		@Override
		public void run() {
			super.run();
			while (true) {
				if (!isOpen) {
					break;
				}
				recv_len = MyApp.driver.ReadData(recv_buff, 64);
				if (recv_len > 0) {
					msg = Message.obtain();
					String read_string = toHexString(recv_buff, recv_len);
					msg.obj = read_string;
					handler.sendMessage(msg);
				}
			}
		}

	}

}
