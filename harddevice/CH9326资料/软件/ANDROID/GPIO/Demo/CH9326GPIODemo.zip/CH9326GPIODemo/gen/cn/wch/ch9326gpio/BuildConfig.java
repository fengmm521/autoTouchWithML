/** Automatically generated file. DO NOT MODIFY */
package cn.wch.ch9326gpio;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}