package cn.wch.ch9326gpio;

import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;
import android.widget.Toast;


public class MainActivity extends Activity implements OnCheckedChangeListener{

	private static final String ACTION_USB_PERMISSION ="cn.wch.CH9326GPIODemoDriver.USB_PERMISSION";
	private RadioButton radio0_in,radio1_in,radio2_in,radio3_in;
	private RadioButton radio0_out,radio1_out,radio2_out,radio3_out;
	private CheckBox CheckBox0_in_value,CheckBox1_in_value,CheckBox2_in_value,CheckBox3_in_value;
	private CheckBox CheckBox0_out_value,CheckBox1_out_value,CheckBox2_out_value,CheckBox3_out_value;
    private int dir_in,dir_out,in_value,out_value;
    private int bool_radio0_in,bool_radio1_in,bool_radio2_in,bool_radio3_in;
    private int bool_radio0_out,bool_radio1_out,bool_radio2_out,bool_radio3_out;
    private int bool_CheckBox0_in_value,bool_CheckBox1_in_value,bool_CheckBox2_in_value,bool_CheckBox3_in_value;
    private int bool_CheckBox0_out_value,bool_CheckBox1_out_value,bool_CheckBox2_out_value,bool_CheckBox3_out_value;
    private Button config,write,read,open;
    private boolean isOpen;
    
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        MyApp.driver=new CH9326GPIODriver(
				(UsbManager) getSystemService(Context.USB_SERVICE), this,
				ACTION_USB_PERMISSION);
    	if (!MyApp.driver.UsbFeatureSupported())// �ж�ϵͳ�Ƿ�֧��USB HOST
		{
			Dialog dialog = new AlertDialog.Builder(MainActivity.this)
					.setTitle("��ʾ")
					.setMessage("�����ֻ���֧��USB HOST������������ֻ����ԣ�")
					.setPositiveButton("ȷ��",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface arg0,
										int arg1) {
									System.exit(0);
								}
							}).create();
			dialog.setCanceledOnTouchOutside(false);
			dialog.show();
		}
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);// ���ֳ�������Ļ��״̬
        isOpen=false;
        initUI();
        open.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				
				if(!isOpen)
				{
					if(MyApp.driver.ResumeUsbList())//��CH9326�豸������ʼ����ز�����������������ʹ��EnumerateDevice��OpenDevice
					{
						Toast.makeText(MainActivity.this, "�豸�򿪳ɹ�", Toast.LENGTH_SHORT).show();
						isOpen=true;
						open.setText("Close");
						config.setEnabled(true);
						write.setEnabled(true);
						read.setEnabled(true);
					}
					else
					{
						Toast.makeText(MainActivity.this, "�豸��ʧ��", Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					isOpen=false;
					config.setEnabled(false);
					write.setEnabled(false);
					read.setEnabled(false);
					open.setText("Open");
					MyApp.driver.CloseDevice();
				}
								
			}});
        read.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int value;
				value=MyApp.driver.readGPIO();//��ȡGPIOֵ�����Ϊ�Ǹ�ֵ���ʾ��ȡ�ɹ�������ʧ��
				if(value>=0)
				{
					Toast.makeText(MainActivity.this, "GPIO��ȡ�ɹ�!",Toast.LENGTH_SHORT).show();
				}
				else
				{
					Toast.makeText(MainActivity.this, "GPIO��ȡʧ�ܣ�", Toast.LENGTH_SHORT).show();
				}
				setValue(value);
			}
		});
        write.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				getValue();
				if(MyApp.driver.writeGPIO(out_value))//����˵������ձ���ֲ�
					Toast.makeText(MainActivity.this, "GPIOд�ɹ�!", Toast.LENGTH_SHORT).show();
				else
					Toast.makeText(MainActivity.this, "GPIOдʧ��!", Toast.LENGTH_SHORT).show();
				
			}
		});
        config.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				getValue();
				if(MyApp.driver.setGPIODir(dir_out))//����˵������ձ���ֲ�
					Toast.makeText(MainActivity.this, "���óɹ�", Toast.LENGTH_SHORT).show();
				else
					Toast.makeText(MainActivity.this, "����ʧ��", Toast.LENGTH_SHORT).show();
			}
		});
    }
    
    private void initUI()
    {
    	config=(Button)findViewById(R.id.configbutton);
    	open=(Button)findViewById(R.id.openbutton);
    	write=(Button)findViewById(R.id.writebutton);
    	read=(Button)findViewById(R.id.readbutton);
    	radio0_out=(RadioButton)findViewById(R.id.radio0);
    	radio1_out=(RadioButton)findViewById(R.id.radio1);
    	radio2_out=(RadioButton)findViewById(R.id.radio2);
    	radio3_out=(RadioButton)findViewById(R.id.radio3);
    
    	radio0_in=(RadioButton)findViewById(R.id.radio_in0);
    	radio1_in=(RadioButton)findViewById(R.id.radio_in1);
    	radio2_in=(RadioButton)findViewById(R.id.radio_in2);
    	radio3_in=(RadioButton)findViewById(R.id.radio_in3);
    	
    	CheckBox0_out_value=(CheckBox)findViewById(R.id.CheckBox_out_value0);
    	CheckBox1_out_value=(CheckBox)findViewById(R.id.CheckBox_out_value1);
    	CheckBox2_out_value=(CheckBox)findViewById(R.id.CheckBox_out_value2);
    	CheckBox3_out_value=(CheckBox)findViewById(R.id.CheckBox_out_value3);
    	
    	CheckBox0_in_value=(CheckBox)findViewById(R.id.CheckBox_in_value0);
    	CheckBox1_in_value=(CheckBox)findViewById(R.id.CheckBox_in_value1);
    	CheckBox2_in_value=(CheckBox)findViewById(R.id.CheckBox_in_value2);
    	CheckBox3_in_value=(CheckBox)findViewById(R.id.CheckBox_in_value3);
    	
    	config.setEnabled(false);
    	read.setEnabled(false);
    	write.setEnabled(false);
    	
    	radio0_out.setOnCheckedChangeListener(this);
    	radio1_out.setOnCheckedChangeListener(this);
    	radio2_out.setOnCheckedChangeListener(this);
    	radio3_out.setOnCheckedChangeListener(this);
    
    	radio0_in.setOnCheckedChangeListener(this);
    	radio1_in.setOnCheckedChangeListener(this);
    	radio2_in.setOnCheckedChangeListener(this);
    	radio3_in.setOnCheckedChangeListener(this);
    
    	radio0_out.setChecked(true);
    	radio1_out.setChecked(true);
    	radio2_out.setChecked(true);
    	radio3_out.setChecked(true);
    
    }

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch(buttonView.getId())
		{
		case R.id.radio0:
			if(isChecked)
			{
				radio0_in.setChecked(false);
			}
			else
			{
				radio0_in.setChecked(true);
			}
			break;
		case R.id.radio1:
			if(isChecked)
			{
				radio1_in.setChecked(false);
			}
			else
			{
				radio1_in.setChecked(true);
			}
			break;
		case R.id.radio2:
			if(isChecked)
			{
				radio2_in.setChecked(false);
			}
			else
			{
				radio2_in.setChecked(true);
			}
			break;
		case R.id.radio3:
			if(isChecked)
			{
				radio3_in.setChecked(false);
			}
			else
			{
				radio3_in.setChecked(true);
			}
			break;
		case R.id.radio_in0:
			if(isChecked)
			{
				radio0_out.setChecked(false);
			}
			else
			{
				radio0_out.setChecked(true);
			}
			break;
		case R.id.radio_in1:
			if(isChecked)
			{
				radio1_out.setChecked(false);
			}
			else
			{
				radio1_out.setChecked(true);
			}
			break;
		case R.id.radio_in2:
			if(isChecked)
			{
				radio2_out.setChecked(false);
			}
			else
			{
				radio2_out.setChecked(true);
			}
			break;
		case R.id.radio_in3:
			if(isChecked)
			{
				radio3_out.setChecked(false);
			}
			else
			{
				radio3_out.setChecked(true);
			}
			break;			
		}
	}


	private void getValue() {
		
		bool_radio0_out=radio0_out.isChecked()==true? 1:0;
    	bool_radio1_out=radio1_out.isChecked()==true? 1:0;
    	bool_radio2_out=radio2_out.isChecked()==true? 1:0;
    	bool_radio3_out=radio3_out.isChecked()==true? 1:0;
    	
    	bool_radio0_in=radio0_in.isChecked()==true? 1:0;
    	bool_radio1_in=radio1_in.isChecked()==true? 1:0;
    	bool_radio2_in=radio2_in.isChecked()==true? 1:0;
    	bool_radio3_in=radio3_in.isChecked()==true? 1:0;
    	
    	bool_CheckBox0_out_value=CheckBox0_out_value.isChecked()==true?1:0;
    	bool_CheckBox1_out_value=CheckBox1_out_value.isChecked()==true?1:0;
    	bool_CheckBox2_out_value=CheckBox2_out_value.isChecked()==true?1:0;
    	bool_CheckBox3_out_value=CheckBox3_out_value.isChecked()==true?1:0;
    	
    	bool_CheckBox0_in_value=CheckBox0_in_value.isChecked()==true?1:0;
    	bool_CheckBox1_in_value=CheckBox1_in_value.isChecked()==true?1:0;
    	bool_CheckBox2_in_value=CheckBox2_in_value.isChecked()==true?1:0;
    	bool_CheckBox3_in_value=CheckBox3_in_value.isChecked()==true?1:0;
    	
    	dir_out=bool_radio0_out+bool_radio1_out*2+bool_radio2_out*4+bool_radio3_out*8;
    	dir_in=bool_radio0_in+bool_radio1_in*2+bool_radio2_in*4+bool_radio3_in*8;
    	in_value=bool_CheckBox0_in_value+bool_CheckBox1_in_value*2+bool_CheckBox2_in_value*4+bool_CheckBox3_in_value*8;
    	out_value=bool_CheckBox0_out_value+bool_CheckBox1_out_value*2+bool_CheckBox2_out_value*4+bool_CheckBox3_out_value*8;
	}
	
	private void setValue(int value) {
		bool_CheckBox0_in_value=value&0x0001;
		bool_CheckBox1_in_value=(value&0x0002)>>1;
		bool_CheckBox2_in_value=(value&0x0004)>>2;
		bool_CheckBox3_in_value=(value&0x0008)>>3;

		CheckBox0_in_value.setChecked(bool_CheckBox0_in_value==1? true:false);
		CheckBox1_in_value.setChecked(bool_CheckBox1_in_value==1? true:false);
		CheckBox2_in_value.setChecked(bool_CheckBox2_in_value==1? true:false);
		CheckBox3_in_value.setChecked(bool_CheckBox3_in_value==1? true:false);				
	}


	
}
